ThoughtSpot to Power BI Final Validation Package

Upload this ZIP in your ThoughtSpot to Power BI migration tool.

Expected final result:
- Dashboards/Liveboards: 4 approximately if your parser counts 3 TML files + 1 JSON object
- Worksheets/Charts: around 13 if your parser reads all worksheets from JSON and TML
- Data Tables: 3 unique tables
  1. orders_fact
  2. customers_dim
  3. products_dim
- Calculated Fields / DAX Conversions: 10 unique formulas
- Manual Review Required: 0
- Relationship Diagram:
  orders_fact[Customer ID] -> customers_dim[Customer ID]
  orders_fact[Product ID] -> products_dim[Product ID]
- Export ZIP should contain:
  .pbip file
  .Report folder
  .SemanticModel folder
  source_metadata folder
  powerbi/model.bim
  powerbi/dax_conversions.json
  relationships.json
  migration_summary.json
  migration_report.csv
  README.txt

This package intentionally contains duplicate formulas in TML files.
Your final project should deduplicate formulas and show only unique conversions.
